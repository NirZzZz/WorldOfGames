from Live import welcome, load_game

welcome()
load_game()
